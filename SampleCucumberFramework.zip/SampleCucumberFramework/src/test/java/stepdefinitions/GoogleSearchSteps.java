package stepdefinitions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Assert;

import com.factory.DriverFactory;
import com.pages.GoogleSearchPage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GoogleSearchSteps {

	private static ArrayList<String> validLinks;
	private static ArrayList<String> arr;
	private String urlname;

	private GoogleSearchPage googleSearchPage = new GoogleSearchPage(DriverFactory.driver);

	@Given("user is on google search page")
	public void user_is_on_google_search_page() {
		DriverFactory.driver.get("https://www.google.com/");

	}

	@When("user enters a given {string}")
	public void user_enters_a_given(String string) {
		googleSearchPage.enterKeyWord(string);
	}

	@Then("google gives search results and store top {int} results for {string} in a file")
	public void google_gives_search_results_and_store_top_results_in_a_file(Integer int1, String keyword) {
		arr = googleSearchPage.fetchResults(int1);
		Assert.assertTrue(arr.size() == int1);

		// this.arr= arr;
		googleSearchPage.fileWriter(arr, keyword);

	}

	@Then("display the content of the {string} file in a console")
	public void display_the_content_of_the_file_in_a_console(String keyword) {
		boolean fileNotEmpty = googleSearchPage.displayResultsInConsole(keyword);
		Assert.assertTrue(fileNotEmpty);
	}

	@Then("the top {int} search results links are validated")
	public void the_search_results_links_are_validated(Integer int1) throws InterruptedException {
		validLinks = googleSearchPage.validateSearchResults(int1);
		System.out.println("Size " + validLinks.size());
		Assert.assertNotNull(validLinks);
		// this.validLinks=validLinks;
	}

	@Then("we open the validated links and search for no of occurances of {string} in the link")
	public void we_open_the_validated_links_and_search_for_no_of_occurances_of_in_the_link(String string) {
		// System.out.println(this.validLinks);
		System.out.println("Occurances :" + validLinks);
		googleSearchPage.openAndfindOccurances(validLinks);

	}
}
