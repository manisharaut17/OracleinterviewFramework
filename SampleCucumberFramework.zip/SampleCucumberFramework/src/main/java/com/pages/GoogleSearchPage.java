package com.pages;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.util.ConfigReader;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GoogleSearchPage extends ConfigReader {

	private WebDriver driver;

	ConfigReader cf = new ConfigReader();

	// Locators
	private By search = By.name("q");
	private By submit = By.name("btnK");
	private By results = By.xpath("//h3[@class=\"LC20lb DKV0Md\"]");
	private By links = By.xpath("//h3[@class=\"LC20lb DKV0Md\"]//parent::a");
	// private By alllinks = By.tagName("a");
	private By word = By.tagName("body");

	public GoogleSearchPage(WebDriver driver) {
		this.driver = driver;
	}

	public void enterKeyWord(String KeyWord) {
		driver.findElement(search).sendKeys(KeyWord);
		driver.findElement(submit).submit();
	}

	public ArrayList<String> fetchResults(Integer int1) {
		List<WebElement> fetchresults = driver.findElements(results);
		List<WebElement> fetchlinks = driver.findElements(links);
		// System.out.println("no of reults :" + fetchresults.size());
		String val = null;
		// int i = 0;
		int count = 0;
		// while (i<fetchresults.size()) {
		ArrayList<String> arrlist = new ArrayList<String>();

		for (int i = 0; i < fetchresults.size(); i++) {
			val = fetchresults.get(i).getText();
			// if (val.length() != 0) {
			String links = fetchlinks.get(i).getAttribute("href");
			// create an array
			try {
				arrlist.add(links);
				// System.out.println(arrlist);
			} catch (ArrayIndexOutOfBoundsException e) {
				e.printStackTrace();
			}
			count++;
			if (count >= int1) {
				break;
			}
		}
		// }
		return arrlist;
	}

	public void fileWriter(ArrayList<String> arr, String keyword) {
		try {
			String path = "src/test/resources/config/searchResults/" + keyword + ".txt";

			File newFile = new File(path);
			if (newFile.exists()) {
				newFile.delete();
			}
			newFile.createNewFile();
			FileWriter fileWriter = new FileWriter(newFile, true);
			BufferedWriter bWriter = new BufferedWriter(fileWriter);
			// PrintWriter pWriter = new PrintWriter(bWriter);
			bWriter.write("----------------------Search Results for " + keyword + " -------------------------\n\n");
			for (int i = 0; i < arr.size(); i++) {
				bWriter.write(arr.get(i));
				bWriter.write("\n");

			}

			bWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean displayResultsInConsole(String keyword) {
		boolean fileNotEmpty = false;
		try {
			String path = "src/test/resources/config/searchResults/" + keyword + ".txt";
			FileReader fileReader = new FileReader(path);
			BufferedReader bReader = new BufferedReader(fileReader);
			String data;
			System.out.println("Printing it in a console :\n\n\n");
			while ((data = bReader.readLine()) != null) {
				fileNotEmpty = true;
				System.out.println(data);
			}
			System.out.println("\n\n\n");
			fileReader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return fileNotEmpty;
	}

	public ArrayList<String> validateSearchResults(int int1) throws InterruptedException {
		ArrayList<String> validLinks = new ArrayList<>();
		List<WebElement> fetchresults = driver.findElements(results);
		List<WebElement> fetchlinks = driver.findElements(links);
		int count = 0;
		for (int i = 0; i < fetchresults.size(); i++) {
			// String val = fetchresults.get(i).getText();
			// if (val.length() != 0) {
			String links = fetchlinks.get(i).getAttribute("href");
			// System.out.println("count: " + int1);
			// System.out.println("href links " + links);
			if (links == null || links.isEmpty()) {
				System.out.println("Link in empty not valid");
			} else {
				try {
					URL url = new URL(links);
					HttpURLConnection hConc = (HttpURLConnection) (url).openConnection();
					hConc.setRequestMethod("HEAD");
					hConc.connect();
					int respCode = hConc.getResponseCode();

					if (respCode >= 400) {
						System.out.println(url + " is a broken link");
					} else {
						System.out.println(url + " is a valid link");

						validLinks.add(links);
					}
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			count++;
			if (count >= int1) {
				break;
			}
		}
		// }
		return validLinks;
	}

	public void openAndfindOccurances(ArrayList<String> validLinks) {
		WebDriverManager.chromedriver().setup();
		for (int i = 0; i < validLinks.size(); i++) {
			System.out.println("No of Occurances inside link - " + validLinks.get(i));

			// WebElement element = driver.findElement(By.linkText(validLinks.get(i)));
			// String clicklnk = Keys.chord(Keys.CONTROL,Keys.ENTER);
			driver.get(validLinks.get(i));


			int size = driver.getPageSource().split("Oracle").length - 1;
			System.out.println(size);

			// WebElement body= driver.findElement(word);
			// String bodyText = body.getText();
			// System.out.println(bodyText);
			// int count = 0;
			
//			while (bodyText.contains("Oracle")){

//			    count++;
//
//				}
//			System.out.println("Occurances of " + i + "is " + count );
//			  bodyText = bodyText.substring(bodyText.indexOf("Oracle") + "Oracle".length());
		}

	}
}
